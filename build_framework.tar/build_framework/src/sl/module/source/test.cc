#include <stdio.h>
#include "test.h"
int main()
{
    printf("Hellor Make file.\n");

    test(20);

    return 0;
}

void test (int val)
{
}
